package dev.runegolem.client;

import dev.runegolem.RuneGolemMod;
import dev.runegolem.entity.StoneGolem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.AnimationUtils;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Cabeza cuadrada enorme, cuerpo pequeno, brazos de losa y patitas cortas. Textura 64x64. */
public class StoneGolemModel extends EntityModel<StoneGolem> {
	public static final ModelLayerLocation LAYER =
			new ModelLayerLocation(new ResourceLocation(RuneGolemMod.MODID, "stone_golem"), "main");

	private final ModelPart root;
	private final ModelPart head;
	private final ModelPart rightArm;
	private final ModelPart leftArm;
	private final ModelPart rightLeg;
	private final ModelPart leftLeg;

	public StoneGolemModel(ModelPart root) {
		this.root = root;
		this.head = root.getChild("head");
		this.rightArm = root.getChild("right_arm");
		this.leftArm = root.getChild("left_arm");
		this.rightLeg = root.getChild("right_leg");
		this.leftLeg = root.getChild("left_leg");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition p = mesh.getRoot();

		p.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0)
				.addBox(-5.0F, -10.0F, -5.0F, 10.0F, 10.0F, 10.0F), PartPose.offset(0.0F, 15.0F, 0.0F));
		p.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 20)
				.addBox(-4.0F, -5.0F, -3.0F, 8.0F, 5.0F, 6.0F), PartPose.offset(0.0F, 20.0F, 0.0F));
		p.addOrReplaceChild("right_arm", CubeListBuilder.create().texOffs(40, 20)
				.addBox(-2.0F, -1.0F, -2.0F, 4.0F, 7.0F, 4.0F), PartPose.offset(-6.0F, 16.0F, 0.0F));
		p.addOrReplaceChild("left_arm", CubeListBuilder.create().texOffs(40, 20).mirror()
				.addBox(-2.0F, -1.0F, -2.0F, 4.0F, 7.0F, 4.0F), PartPose.offset(6.0F, 16.0F, 0.0F));
		p.addOrReplaceChild("right_leg", CubeListBuilder.create().texOffs(0, 36)
				.addBox(-1.5F, 0.0F, -1.5F, 3.0F, 4.0F, 3.0F), PartPose.offset(-2.5F, 20.0F, 0.0F));
		p.addOrReplaceChild("left_leg", CubeListBuilder.create().texOffs(0, 36).mirror()
				.addBox(-1.5F, 0.0F, -1.5F, 3.0F, 4.0F, 3.0F), PartPose.offset(2.5F, 20.0F, 0.0F));

		return LayerDefinition.create(mesh, 64, 64);
	}

	@Override
	public void setupAnim(StoneGolem golem, float limbSwing, float limbSwingAmount, float ageInTicks,
						  float netHeadYaw, float headPitch) {
		this.head.yRot = netHeadYaw * ((float) Math.PI / 180F);
		this.head.xRot = headPitch * ((float) Math.PI / 180F);

		this.rightLeg.xRot = Mth.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
		this.leftLeg.xRot = Mth.cos(limbSwing * 0.6662F + (float) Math.PI) * 1.4F * limbSwingAmount;

		// brazos algo separados del cuerpo, como en el diseno
		this.rightArm.zRot = 0.25F;
		this.leftArm.zRot = -0.25F;
		this.rightArm.xRot = Mth.cos(limbSwing * 0.6662F + (float) Math.PI) * limbSwingAmount;
		this.leftArm.xRot = Mth.cos(limbSwing * 0.6662F) * limbSwingAmount;
		this.rightArm.yRot = 0.0F;
		this.leftArm.yRot = 0.0F;

		if (golem.isAggressive()) {
			AnimationUtils.animateZombieArms(this.leftArm, this.rightArm, true, this.attackTime, ageInTicks);
		}
	}

	@Override
	public void renderToBuffer(PoseStack pose, VertexConsumer buffer, int light, int overlay,
							   float r, float g, float b, float a) {
		this.root.render(pose, buffer, light, overlay, r, g, b, a);
	}
}
