package dev.runegolem.registry;

import dev.runegolem.RuneGolemMod;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
	public static final DeferredRegister<Item> ITEMS =
			DeferredRegister.create(ForgeRegistries.ITEMS, RuneGolemMod.MODID);

	public static final RegistryObject<Item> RUNE_STONE = ITEMS.register("rune_stone",
			() -> new Item(new Item.Properties()));

	public static final RegistryObject<Item> RUNIC_TABLET = ITEMS.register("runic_tablet",
			() -> new Item(new Item.Properties()));

	public static final RegistryObject<Item> STONE_GOLEM_SPAWN_EGG = ITEMS.register("stone_golem_spawn_egg",
			() -> new ForgeSpawnEggItem(ModEntities.STONE_GOLEM, 0x7C7F78, 0x3A8DDE, new Item.Properties()));
}
