package dev.runegolem;

import dev.runegolem.registry.ModEntities;
import dev.runegolem.registry.ModItems;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(RuneGolemMod.MODID)
public class RuneGolemMod {
	public static final String MODID = "runegolem";

	public RuneGolemMod() {
		IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
		ModEntities.ENTITIES.register(bus);
		ModItems.ITEMS.register(bus);
	}
}
