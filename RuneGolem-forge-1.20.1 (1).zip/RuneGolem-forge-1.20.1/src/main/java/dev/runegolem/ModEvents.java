package dev.runegolem;

import dev.runegolem.entity.StoneGolem;
import dev.runegolem.registry.ModEntities;
import dev.runegolem.registry.ModItems;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = RuneGolemMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEvents {

	@SubscribeEvent
	public static void attributes(EntityAttributeCreationEvent event) {
		event.put(ModEntities.STONE_GOLEM.get(), StoneGolem.createAttributes().build());
	}

	@SubscribeEvent
	public static void spawnPlacement(SpawnPlacementRegisterEvent event) {
		event.register(ModEntities.STONE_GOLEM.get(), SpawnPlacements.Type.ON_GROUND,
				Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, StoneGolem::checkSpawn,
				SpawnPlacementRegisterEvent.Operation.REPLACE);
	}

	@SubscribeEvent
	public static void creativeTabs(BuildCreativeModeTabContentsEvent event) {
		if (event.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			event.accept(ModItems.RUNE_STONE);
			event.accept(ModItems.RUNIC_TABLET);
		}
		if (event.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			event.accept(ModItems.STONE_GOLEM_SPAWN_EGG);
		}
	}
}
