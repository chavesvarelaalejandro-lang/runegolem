package dev.runegolem.client;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.runegolem.RuneGolemMod;
import dev.runegolem.entity.StoneGolem;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class StoneGolemRenderer extends MobRenderer<StoneGolem, StoneGolemModel> {
	private static final ResourceLocation TEXTURE =
			new ResourceLocation(RuneGolemMod.MODID, "textures/entity/stone_golem.png");

	public StoneGolemRenderer(EntityRendererProvider.Context context) {
		super(context, new StoneGolemModel(context.bakeLayer(StoneGolemModel.LAYER)), 0.4F);
		this.addLayer(new GolemEyesLayer(this));
	}

	@Override
	public ResourceLocation getTextureLocation(StoneGolem golem) {
		return TEXTURE;
	}

	@Override
	protected void scale(StoneGolem golem, PoseStack pose, float partialTick) {
		pose.scale(0.4F, 0.4F, 0.4F);
	}
}
