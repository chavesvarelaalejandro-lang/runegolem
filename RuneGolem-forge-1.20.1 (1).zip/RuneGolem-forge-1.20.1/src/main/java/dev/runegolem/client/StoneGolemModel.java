package dev.runegolem.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.runegolem.RuneGolemMod;
import dev.runegolem.entity.StoneGolem;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Mini golem de piedra (diseno con musgo): cabeza cubica enorme con nariz de bloque, torso corto,
 * brazos de losa abiertos hacia los lados y patas cortas y gruesas.
 *
 * El modelo esta hecho al DOBLE de resolucion (1 unidad = 0,5 pixel vanilla) para que el musgo tenga
 * mucho detalle; el renderer lo reduce con scale(0.4). Textura 128x128.
 */
public class StoneGolemModel extends EntityModel<StoneGolem> {
	public static final ModelLayerLocation LAYER =
			new ModelLayerLocation(new ResourceLocation(RuneGolemMod.MODID, "stone_golem"), "main");

	// pivotes base de cada parte (los pies quedan en y = 24, como en los modelos vanilla)
	private static final float HEAD_Y = 0.0F;
	private static final float BODY_Y = 14.0F;
	private static final float ARM_Y = 2.0F;
	private static final float ARM_X = 14.0F;
	private static final float LEG_Y = 14.0F;
	private static final float ARM_SPLAY = 0.30F; // brazos abiertos en reposo

	private final ModelPart root;
	private final ModelPart head;
	private final ModelPart body;
	private final ModelPart rightArm;
	private final ModelPart leftArm;
	private final ModelPart rightLeg;
	private final ModelPart leftLeg;

	public StoneGolemModel(ModelPart root) {
		this.root = root;
		this.head = root.getChild("head");
		this.body = root.getChild("body");
		this.rightArm = root.getChild("right_arm");
		this.leftArm = root.getChild("left_arm");
		this.rightLeg = root.getChild("right_leg");
		this.leftLeg = root.getChild("left_leg");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition p = mesh.getRoot();

		PartDefinition head = p.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0)
				.addBox(-10.0F, -20.0F, -10.0F, 20.0F, 20.0F, 20.0F), PartPose.offset(0.0F, HEAD_Y, 0.0F));
		// nariz de bloque que sobresale (se mueve con la cabeza)
		head.addOrReplaceChild("nose", CubeListBuilder.create().texOffs(80, 0)
				.addBox(-3.0F, -9.0F, -14.0F, 6.0F, 8.0F, 4.0F), PartPose.ZERO);

		p.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 40)
				.addBox(-10.0F, -14.0F, -7.0F, 20.0F, 14.0F, 14.0F), PartPose.offset(0.0F, BODY_Y, 0.0F));

		p.addOrReplaceChild("right_arm", CubeListBuilder.create().texOffs(68, 40)
				.addBox(-4.0F, -2.0F, -5.0F, 8.0F, 22.0F, 10.0F), PartPose.offset(-ARM_X, ARM_Y, 0.0F));
		p.addOrReplaceChild("left_arm", CubeListBuilder.create().texOffs(68, 40).mirror()
				.addBox(-4.0F, -2.0F, -5.0F, 8.0F, 22.0F, 10.0F), PartPose.offset(ARM_X, ARM_Y, 0.0F));

		p.addOrReplaceChild("right_leg", CubeListBuilder.create().texOffs(0, 72)
				.addBox(-5.0F, 0.0F, -5.0F, 10.0F, 10.0F, 10.0F), PartPose.offset(-5.5F, LEG_Y, 0.0F));
		p.addOrReplaceChild("left_leg", CubeListBuilder.create().texOffs(0, 72).mirror()
				.addBox(-5.0F, 0.0F, -5.0F, 10.0F, 10.0F, 10.0F), PartPose.offset(5.5F, LEG_Y, 0.0F));

		return LayerDefinition.create(mesh, 128, 128);
	}

	@Override
	public void setupAnim(StoneGolem golem, float limbSwing, float limbSwingAmount, float ageInTicks,
						  float netHeadYaw, float headPitch) {
		final float pi = (float) Math.PI;
		boolean angry = golem.isRedEyes();
		boolean attacking = golem.isAggressive();

		// ---- marcha: pasos cortos y pesados; mas rapidos y duros si esta enfadado
		float amt = Math.min(limbSwingAmount * (angry ? 1.35F : 1.0F), 1.0F);
		float swing = limbSwing * (angry ? 0.75F : 0.55F);
		float breathe = Mth.sin(ageInTicks * 0.09F);   // respiracion
		float sway = Mth.sin(ageInTicks * 0.05F);      // balanceo lento en reposo
		float still = 1.0F - amt;                      // 1 = quieto, 0 = andando

		// el cuerpo sube a mitad de paso y "pisa" al apoyar el pie
		float lift = (1.0F - Math.abs(Mth.cos(swing))) * amt * (angry ? 2.0F : 1.4F);
		float idle = breathe * 0.5F * still;

		this.body.y = BODY_Y - lift + idle;
		this.head.y = HEAD_Y - lift + idle * 1.4F;
		this.rightArm.y = ARM_Y - lift + idle;
		this.leftArm.y = ARM_Y - lift + idle;

		// ---- cabeza: sigue la mirada; al andar se balancea, en reposo "respira"
		this.head.yRot = netHeadYaw * (pi / 180F);
		this.head.xRot = headPitch * (pi / 180F) + (angry ? 0.18F : 0.0F);
		this.head.zRot = Mth.cos(swing) * 0.05F * amt + sway * 0.04F * still;
		this.head.z = 0.0F;

		// ---- piernas: zancada + levantan el pie a mitad del paso
		this.rightLeg.xRot = Mth.cos(swing) * 1.1F * amt;
		this.leftLeg.xRot = Mth.cos(swing + pi) * 1.1F * amt;
		this.rightLeg.y = LEG_Y - Math.max(0.0F, Mth.sin(swing)) * amt * 1.8F;
		this.leftLeg.y = LEG_Y - Math.max(0.0F, -Mth.sin(swing)) * amt * 1.8F;

		// ---- brazos: abiertos hacia los lados, contrapeso de las piernas + balanceo en reposo
		float armSwing = amt * 0.8F;
		this.rightArm.xRot = Mth.cos(swing + pi) * armSwing + sway * 0.04F * still;
		this.leftArm.xRot = Mth.cos(swing) * armSwing - sway * 0.04F * still;
		this.rightArm.yRot = 0.0F;
		this.leftArm.yRot = 0.0F;
		this.rightArm.zRot = ARM_SPLAY + breathe * 0.025F;
		this.leftArm.zRot = -ARM_SPLAY - breathe * 0.025F;
		this.rightArm.z = 0.0F;
		this.leftArm.z = 0.0F;
		this.body.xRot = 0.0F;

		// ---- ataque (ojos rojos + objetivo): brazos al frente, se inclina y golpea con los dos punos
		if (attacking) {
			float t = this.attackTime;
			float f = Mth.sin(t * pi);
			float f1 = Mth.sin((1.0F - (1.0F - t) * (1.0F - t)) * pi);
			float armsUp = -1.45F + Mth.sin(ageInTicks * 0.2F) * 0.05F;

			this.rightArm.xRot = armsUp - (f * 1.2F - f1 * 0.4F);
			this.leftArm.xRot = armsUp - (f * 1.2F - f1 * 0.4F);
			this.rightArm.yRot = -0.12F;
			this.leftArm.yRot = 0.12F;
			this.rightArm.zRot = 0.08F;
			this.leftArm.zRot = -0.08F;

			float lean = 0.12F + f * 0.2F;                 // se inclina hacia delante al golpear
			this.body.xRot = lean;
			this.head.xRot += lean;
			float shift = -Mth.sin(lean);
			this.head.z = 14.0F * shift;                    // cabeza y hombros siguen la inclinacion
			this.rightArm.z = 12.0F * shift;
			this.leftArm.z = 12.0F * shift;
		}
	}

	@Override
	public void renderToBuffer(PoseStack pose, VertexConsumer buffer, int light, int overlay,
							   float r, float g, float b, float a) {
		this.root.render(pose, buffer, light, overlay, r, g, b, a);
	}
}
