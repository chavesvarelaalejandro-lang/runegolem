package dev.runegolem.client;

import dev.runegolem.RuneGolemMod;
import dev.runegolem.registry.ModEntities;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = RuneGolemMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {

	@SubscribeEvent
	public static void layers(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(StoneGolemModel.LAYER, StoneGolemModel::createBodyLayer);
	}

	@SubscribeEvent
	public static void renderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(ModEntities.STONE_GOLEM.get(), StoneGolemRenderer::new);
	}
}
