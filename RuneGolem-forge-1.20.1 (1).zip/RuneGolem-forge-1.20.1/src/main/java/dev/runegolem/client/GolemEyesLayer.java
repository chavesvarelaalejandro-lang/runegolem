package dev.runegolem.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.runegolem.RuneGolemMod;
import dev.runegolem.entity.StoneGolem;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/** Ojos que brillan en la oscuridad: azules o rojos segun el estado del golem. */
public class GolemEyesLayer extends RenderLayer<StoneGolem, StoneGolemModel> {
	private static final ResourceLocation BLUE =
			new ResourceLocation(RuneGolemMod.MODID, "textures/entity/stone_golem_eyes_blue.png");
	private static final ResourceLocation RED =
			new ResourceLocation(RuneGolemMod.MODID, "textures/entity/stone_golem_eyes_red.png");

	public GolemEyesLayer(RenderLayerParent<StoneGolem, StoneGolemModel> parent) {
		super(parent);
	}

	@Override
	public void render(PoseStack pose, MultiBufferSource buffers, int light, StoneGolem golem, float limbSwing,
					   float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
		VertexConsumer consumer = buffers.getBuffer(RenderType.eyes(golem.isRedEyes() ? RED : BLUE));
		this.getParentModel().renderToBuffer(pose, consumer, 0xF000F0, OverlayTexture.NO_OVERLAY, 1.0F, 1.0F, 1.0F, 1.0F);
	}
}
