package dev.runegolem.entity;

import dev.runegolem.registry.ModItems;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.BuiltInLootTables;

/**
 * Mini golem de piedra.
 *  - Ojos azules: pasivo (de dia, al aire libre).
 *  - Ojos rojos: hostil (de noche o en cuevas / sin cielo). Se calcula solo, cada medio segundo.
 *  - Una orquidea azul sobre un golem azul lo "calma" para siempre (nunca se pone rojo).
 */
public class StoneGolem extends PathfinderMob {

	// ---- AJUSTES (cambialos aqui si quieres equilibrar el mob) ----
	private static final double MAX_HEALTH = 12.0D;   // poca vida
	private static final double ARMOR = 10.0D;        // mucha resistencia: espada de diamante (7) hace ~5.2 -> aguanta 2 golpes, muere al 3.o
	private static final double SPEED = 0.13D;        // zombi = 0.23  (~56 %)
	private static final double ATTACK_DAMAGE = 3.0D; // igual que el zombi
	private static final int CAVE_SKY_LIGHT = 7;      // luz de cielo por debajo de esto = cueva
	private static final float RUNE_STONE_CHANCE = 0.15F; // probabilidad de soltar la piedra runica

	private static final EntityDataAccessor<Boolean> RED_EYES =
			SynchedEntityData.defineId(StoneGolem.class, EntityDataSerializers.BOOLEAN);
	private static final EntityDataAccessor<Boolean> CALM =
			SynchedEntityData.defineId(StoneGolem.class, EntityDataSerializers.BOOLEAN);

	public StoneGolem(EntityType<? extends StoneGolem> type, Level level) {
		super(type, level);
		this.xpReward = 5;
	}

	public static AttributeSupplier.Builder createAttributes() {
		return Mob.createMobAttributes()
				.add(Attributes.MAX_HEALTH, MAX_HEALTH)
				.add(Attributes.MOVEMENT_SPEED, SPEED)
				.add(Attributes.ATTACK_DAMAGE, ATTACK_DAMAGE)
				.add(Attributes.ARMOR, ARMOR)
				.add(Attributes.KNOCKBACK_RESISTANCE, 0.5D)
				.add(Attributes.FOLLOW_RANGE, 32.0D);
	}

	/** Puede aparecer de dia (azul) y de noche / en cuevas (rojo): sin condicion de luz. */
	public static boolean checkSpawn(EntityType<StoneGolem> type, ServerLevelAccessor level, MobSpawnType reason,
									 BlockPos pos, RandomSource random) {
		return Mob.checkMobSpawnRules(type, level, reason, pos, random);
	}

	@Override
	protected void registerGoals() {
		this.goalSelector.addGoal(0, new FloatGoal(this));
		this.goalSelector.addGoal(1, new RedOnlyMeleeGoal(this));
		this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
		this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
		this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
		// Solo ataca a jugadores y solo con los ojos rojos
		this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false,
				(LivingEntity e) -> this.isRedEyes()));
	}

	// ------------------------------------------------------------------ estado

	@Override
	protected void defineSynchedData() {
		super.defineSynchedData();
		this.entityData.define(RED_EYES, false);
		this.entityData.define(CALM, false);
	}

	public boolean isRedEyes() { return this.entityData.get(RED_EYES); }
	public void setRedEyes(boolean v) { this.entityData.set(RED_EYES, v); }
	public boolean isCalm() { return this.entityData.get(CALM); }
	public void setCalm(boolean v) { this.entityData.set(CALM, v); }

	@Override
	public void addAdditionalSaveData(CompoundTag tag) {
		super.addAdditionalSaveData(tag);
		tag.putBoolean("Calm", isCalm());
		tag.putBoolean("RedEyes", isRedEyes());
	}

	@Override
	public void readAdditionalSaveData(CompoundTag tag) {
		super.readAdditionalSaveData(tag);
		setCalm(tag.getBoolean("Calm"));
		setRedEyes(tag.getBoolean("RedEyes"));
	}

	@Nullable
	@Override
	public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
										@Nullable SpawnGroupData data, @Nullable CompoundTag tag) {
		SpawnGroupData result = super.finalizeSpawn(level, difficulty, reason, data, tag);
		updateEyes();
		return result;
	}

	@Override
	public void aiStep() {
		super.aiStep();
		if (!this.level().isClientSide && this.tickCount % 10 == 0) {
			updateEyes();
		}
	}

	private void updateEyes() {
		boolean dark = this.level().isNight()
				|| this.level().getBrightness(LightLayer.SKY, this.blockPosition()) < CAVE_SKY_LIGHT;
		boolean red = !isCalm() && dark;
		if (red != isRedEyes()) {
			setRedEyes(red);
			if (!red) {
				this.setTarget(null);
			}
			this.playSound(SoundEvents.STONE_PLACE, 0.8F, red ? 0.7F : 1.2F);
		}
	}

	// ------------------------------------------------------------------ orquidea azul

	@Override
	public InteractionResult mobInteract(Player player, InteractionHand hand) {
		ItemStack stack = player.getItemInHand(hand);
		if (stack.is(Items.BLUE_ORCHID) && !isCalm() && !isRedEyes()) {
			if (!this.level().isClientSide) {
				setCalm(true);
				this.setPersistenceRequired(); // un golem calmado no desaparece
				if (!player.getAbilities().instabuild) {
					stack.shrink(1);
				}
				if (this.level() instanceof ServerLevel server) {
					server.sendParticles(ParticleTypes.HAPPY_VILLAGER, getX(), getY() + 0.8D, getZ(),
							8, 0.3D, 0.3D, 0.3D, 0.02D);
				}
				this.playSound(SoundEvents.AMETHYST_BLOCK_CHIME, 1.0F, 1.0F);
			}
			return InteractionResult.sidedSuccess(this.level().isClientSide);
		}
		return super.mobInteract(player, hand);
	}

	// ------------------------------------------------------------------ drops

	@Override
	protected ResourceLocation getDefaultLootTable() {
		return BuiltInLootTables.EMPTY; // los drops se hacen abajo, segun el color de ojos
	}

	@Override
	protected void dropCustomDeathLoot(DamageSource source, int looting, boolean recentlyHit) {
		super.dropCustomDeathLoot(source, looting, recentlyHit);
		this.spawnAtLocation(new ItemStack(Items.COBBLESTONE, 1 + this.random.nextInt(2 + looting)));
		this.spawnAtLocation(new ItemStack(isRedEyes() ? Items.REDSTONE : Items.LAPIS_LAZULI, 2));
		if (this.random.nextFloat() < RUNE_STONE_CHANCE) {
			this.spawnAtLocation(new ItemStack(ModItems.RUNE_STONE.get()));
		}
	}

	// ------------------------------------------------------------------ sonidos

	@Override
	protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.STONE_HIT; }

	@Override
	protected SoundEvent getDeathSound() { return SoundEvents.STONE_BREAK; }

	@Override
	protected void playStepSound(BlockPos pos, BlockState state) {
		this.playSound(SoundEvents.STONE_STEP, 0.15F, 1.0F);
	}

	// ------------------------------------------------------------------ IA

	private static class RedOnlyMeleeGoal extends MeleeAttackGoal {
		private final StoneGolem golem;

		RedOnlyMeleeGoal(StoneGolem golem) {
			super(golem, 1.0D, false);
			this.golem = golem;
		}

		@Override
		public boolean canUse() { return golem.isRedEyes() && super.canUse(); }

		@Override
		public boolean canContinueToUse() { return golem.isRedEyes() && super.canContinueToUse(); }
	}
}
