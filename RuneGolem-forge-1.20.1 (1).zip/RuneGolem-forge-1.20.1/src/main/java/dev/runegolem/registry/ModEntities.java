package dev.runegolem.registry;

import dev.runegolem.RuneGolemMod;
import dev.runegolem.entity.StoneGolem;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
	public static final DeferredRegister<EntityType<?>> ENTITIES =
			DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, RuneGolemMod.MODID);

	public static final RegistryObject<EntityType<StoneGolem>> STONE_GOLEM = ENTITIES.register("stone_golem",
			() -> EntityType.Builder.of(StoneGolem::new, MobCategory.MONSTER)
					.sized(0.9F, 1.1F)
					.clientTrackingRange(8)
					.build("stone_golem"));
}
