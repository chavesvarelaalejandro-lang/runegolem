# Rune Golem (Forge 1.20.1)
Mini golem de piedra (ojos azules de dia, rojos de noche / cuevas), piedra runica y tablilla runica.
Compilar: ./gradlew build  (JDK 17)  ->  build/libs/runegolem-1.0.0.jar
